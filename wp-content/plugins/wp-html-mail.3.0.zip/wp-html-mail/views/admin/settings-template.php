<div class="postbox">

    <div id="wp-html-mail-template-designer">
        
    </div>
</div>