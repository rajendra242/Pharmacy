<?php

return [
	'title' => __( 'Backup', 'better-wp-security' ),
];
