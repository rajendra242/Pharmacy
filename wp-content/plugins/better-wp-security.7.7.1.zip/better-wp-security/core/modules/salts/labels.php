<?php

return [
	'title' => __( 'WordPress Salts', 'better-wp-security' ),
];
