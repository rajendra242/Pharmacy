<?php

return [
	'title' => __( 'Security Check', 'better-wp-security' ),
];
