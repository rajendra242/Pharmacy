<?php

return [
	'title' => __( 'Notification Center', 'better-wp-security' ),
];
