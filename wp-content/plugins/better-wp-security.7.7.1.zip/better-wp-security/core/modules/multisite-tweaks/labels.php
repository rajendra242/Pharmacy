<?php

return [
	'title' => __( 'Multisite Tweaks', 'better-wp-security' ),
];
