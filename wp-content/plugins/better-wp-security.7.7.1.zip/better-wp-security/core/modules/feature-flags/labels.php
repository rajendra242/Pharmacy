<?php

return [
	'title' => __( 'Feature Flags', 'better-wp-security' ),
];
