<?php

return [
	'title' => __( 'Password Requirements', 'better-wp-security' ),
];
