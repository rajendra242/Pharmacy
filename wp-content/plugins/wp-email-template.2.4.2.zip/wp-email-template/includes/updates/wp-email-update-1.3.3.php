<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $wp_email_template_exclude_subject_data;
$wp_email_template_exclude_subject_data->install_database();