<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<title>Contact Form 7 Email Add on</title>
</head>
	<body style="margin: 0; padding: 0">
		<table width="100%" cellpadding="0" cellspacing="0" bgcolor="#222222" border="0" style="background-image: url([plugin_url]admin/assets/images/table-bg.png); background-color: #222222; padding-top: 20px;">
			<tr>
				<td align="center" style="padding-left: 15px; padding-right: 15px;">
					<div style="width: 100%; max-width: 650px; margin: 0 auto;">
						<table width="100%" cellpadding="0" cellspacing="0" border="0" style="width: 100%; max-width: 650px; margin: 0 auto;">
							<tbody>
								<tr>
									<td>
										<table width="100%" cellpadding="0" cellspacing="0" border="0" style="width: 100%; max-width: 620px; margin: 0 auto;">
											<tbody>
												<tr>
													<td height="60"></td>
												</tr>
												<tr>
													<td style="text-align: center;">
														<a href="https://www.krishaweb.com" target="_blank" style="display: inline-block;"><img src="[plugin_url]admin/assets/images/logo.png" alt=""></a>
													</td>
												</tr>
												<tr>
													<td height="60"></td>
												</tr>
												<tr>
													<td>
														<table width="100%" cellpadding="0" cellspacing="0" border="0">
															<tbody>
																<tr>
																	<td width="600" style="padding-top: 50px; padding-bottom: 100px;">
																		<table width="100%" cellpadding="0" cellspacing="0" border="0">
																			<tbody>
																				<tr>
																					<td style="font-family: Courier, Courier New, monospace, Arial; font-weight: bold; font-size: 28px; line-height: 32px; color: #f18f4e; text-align: center; padding-bottom: 25px; padding-left: 15px; padding-right: 15px;">
																						Hello [your-name],
																					</td>
																				</tr>
																				<tr>
																					<td style="font-family: Courier, Courier New, monospace, Arial; font-weight: bold; font-size: 24px; line-height: 38px; color: #f18f4e; text-align: center; padding-bottom: 25px; padding-left: 15px; padding-right: 15px;">
																						Thanks for getting in touch
																					</td>
																				</tr>
																				<tr>
																					<td style="font-family: Courier, Courier New, monospace, Arial; font-weight: normal; font-size: 20px; line-height: 28px; color: #f9f9f9; text-align: center; padding-bottom: 30px; padding-left: 15px; padding-right: 15px;">
																						We have received your inquiry. Happy to have you in our precious clients list. One of our sales representative will be in touch with you soon. <br>Till than stay tuned with the updates from KrishaWeb...
																					</td>
																				</tr>
																				<tr>
																					<td height="20"></td>
																				</tr>
																				<tr>
																					<td>
																						<div style="text-align: center;">
																							<a href="https://www.krishaweb.com/blog" style="display: inline-block; padding: 12px 20px 12px 20px; background: #f18f4e; color: #ffffff; font-size: 20px; text-decoration: none; font-family: Courier, Courier New, monospace, Arial; font-weight: bold; text-transform: uppercase; letter-spacing: 0.050em;">fresh from blog</a>
																						</div>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</td>
			</tr>
			<tr>
				<td style="padding-top: 50px;">
					<div style="width: 100%; max-width: 620px; margin: 0 auto;">
						<table width="100%" cellpadding="0" cellspacing="0" border="0" style="">
							<tr>
								<td style="font-family: Courier, Courier New, monospace, Arial; font-weight: normal; font-size: 14px; line-height: 24px; color: #ffffff; text-align: left; padding-bottom: 30px; padding-top: 15px; padding-left: 15px; padding-right: 15px;">
									Copyright &copy; <?php echo date_i18n( 'Y' ); ?> <a href="https://www.krishaweb.com/" target="_blank" style="text-decoration: none; font-weight: bold; color: #ffffff">KrishaWeb</a>
								</td>
								<td style="font-family: Courier, Courier New, monospace, Arial; font-weight: normal; font-size: 14px; line-height: 24px; color: #ffffff; text-align: right; padding-bottom: 30px; padding-top: 15px; padding-left: 15px; padding-right: 15px;">
									Powered by <a href="#" target="_blank" style="text-decoration: none; font-weight: bold; color: #ffffff;">Contact Form 7 Email Addon</a>
								</td>
							</tr>
						</table>
					</div>
				</td>
			</tr>
		</table>
	</body>
</html>