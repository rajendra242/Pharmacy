<?php
$settings = Mailtpl::opts();
include_once( 'partials/header.php' );
include_once( 'partials/email-content.php');
include_once( 'partials/footer.php' );
