<?php get_header(); ?>
<div class="main-content-wrapper">
	<div class="container">
		<div class="row">
			<div class="col-xl-12">
				<?php woocommerce_content(); ?>
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>