<?php if(is_front_page()){ ?>
	<?php the_content(); ?>
<?php } else { ?>
	<?php the_content(); ?>
<?php } ?>